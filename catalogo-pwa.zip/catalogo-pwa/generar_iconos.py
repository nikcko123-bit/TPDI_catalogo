#!/usr/bin/env python3
"""Genera los iconos icon-192.png e icon-512.png para la PWA del catálogo."""

try:
    from PIL import Image, ImageDraw
except ImportError:
    import subprocess, sys
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'Pillow', '--break-system-packages', '-q'])
    from PIL import Image, ImageDraw

import os

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

def make_icon(size):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Background rounded rect (simulate with ellipse corners)
    bg_color = (45, 80, 22)  # #2d5016
    draw.rounded_rectangle([0, 0, size-1, size-1], radius=int(size*0.22), fill=bg_color)

    # Simple grid icon (2x2 squares) to represent catalog
    pad = int(size * 0.22)
    gap = int(size * 0.06)
    cell = (size - 2*pad - gap) // 2
    white = (255, 255, 255, 230)

    for row in range(2):
        for col in range(2):
            x = pad + col * (cell + gap)
            y = pad + row * (cell + gap)
            draw.rounded_rectangle([x, y, x+cell, y+cell], radius=int(cell*0.18), fill=white)

    return img

for s in [192, 512]:
    icon = make_icon(s)
    path = os.path.join(OUTPUT_DIR, f'icon-{s}.png')
    icon.save(path)
    print(f'Generado: {path}')

print('Iconos listos.')
